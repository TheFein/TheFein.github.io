
const board = Array(9).fill(null);
let currentPlayer = 'X';

function handleClick(cell, index) {
    if (board[index] || checkWinner()) return;
    board[index] = currentPlayer;
    cell.textContent = currentPlayer;
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    if (checkWinner()) alert(checkWinner() + ' wins!');
}

function checkWinner() {
    const winningCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    for (const combo of winningCombinations) {
        const [a, b, c] = combo;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
    }
    return null;
}

function resetGame() {
    board.fill(null);
    document.querySelectorAll('#tic-tac-toe-board div').forEach(cell => cell.textContent = '');
    currentPlayer = 'X';
}

document.addEventListener('DOMContentLoaded', () => {
    const boardElement = document.getElementById('tic-tac-toe-board');
    boardElement.innerHTML = '';
    board.forEach((_, i) => {
        const cell = document.createElement('div');
        cell.addEventListener('click', () => handleClick(cell, i));
        boardElement.appendChild(cell);
    });
});
