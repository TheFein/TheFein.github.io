
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const box = 20;
let snake = [{x: 9 * box, y: 10 * box}];
let direction = 'RIGHT';
let food = {x: Math.floor(Math.random() * 19) * box, y: Math.floor(Math.random() * 19) * box};

document.addEventListener('keydown', changeDirection);

function changeDirection(event) {
    if (event.key === 'ArrowRight' && direction !== 'LEFT') direction = 'RIGHT';
    else if (event.key === 'ArrowLeft' && direction !== 'RIGHT') direction = 'LEFT';
    else if (event.key === 'ArrowUp' && direction !== 'DOWN') direction = 'UP';
    else if (event.key === 'ArrowDown' && direction !== 'UP') direction = 'DOWN';
}

function drawGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    snake.forEach(part => ctx.fillRect(part.x, part.y, box, box));
    ctx.fillRect(food.x, food.y, box, box);

    let snakeX = snake[0].x;
    let snakeY = snake[0].y;
    if (direction === 'RIGHT') snakeX += box;
    if (direction === 'LEFT') snakeX -= box;
    if (direction === 'UP') snakeY -= box;
    if (direction === 'DOWN') snakeY += box;

    if (snakeX === food.x && snakeY === food.y) {
        food = {x: Math.floor(Math.random() * 19) * box, y: Math.floor(Math.random() * 19) * box};
    } else {
        snake.pop();
    }
    
    const newHead = {x: snakeX, y: snakeY};
    snake.unshift(newHead);

    if (snakeX < 0 || snakeY < 0 || snakeX >= canvas.width || snakeY >= canvas.height || collision(newHead, snake)) {
        clearInterval(game);
        alert('Game Over');
    }
}

function collision(head, snake) {
    return snake.slice(1).some(part => part.x === head.x && part.y === head.y);
}

let game = setInterval(drawGame, 100);
